package kr.ac.springboot.term.resume;

import org.springframework.stereotype.Service;

@Service
public class ResumeService {
}
